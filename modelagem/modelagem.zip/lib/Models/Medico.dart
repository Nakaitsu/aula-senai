class Medico {
  late int id;
  String nome;
  int atendimentos = 0;
  static List<Medico> Lista = [];

  Medico(this.nome);
}