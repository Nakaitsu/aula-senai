class Medicamento {
  late int id;
  String nome;
  int quantidade;
  static List<Medicamento> Lista = [];

  Medicamento(this.nome, this.quantidade);
}