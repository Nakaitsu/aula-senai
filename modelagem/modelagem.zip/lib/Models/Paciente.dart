class Paciente {
  late int id;
  String nome;
  static List<Paciente> Lista = [];

  Paciente(this.nome);
}

